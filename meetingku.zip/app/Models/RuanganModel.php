<?php

namespace App\Models;

use CodeIgniter\Model;

class RuanganModel extends Model
{
    protected $table = 'ruangan';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['nama_ruangan', 'tipe'];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Validation rules
    protected $validationRules = [
        'nama_ruangan' => 'required|min_length[3]|max_length[100]|is_unique[ruangan.nama_ruangan,id,{id}]',
        'tipe' => 'required|in_list[Online,Offline,Hybrid]'
    ];

    protected $validationMessages = [
        'nama_ruangan' => [
            'required' => 'Nama ruangan harus diisi',
            'min_length' => 'Nama ruangan minimal 3 karakter',
            'max_length' => 'Nama ruangan maksimal 100 karakter',
            'is_unique' => 'Nama ruangan sudah digunakan'
        ],
        'tipe' => [
            'required' => 'Tipe ruangan harus diisi',
            'in_list' => 'Tipe ruangan harus Online, Offline, atau Hybrid'
        ]
    ];

    // Check if room can be deleted (no approved meetings)
    public function canDelete($ruanganId)
    {
        $approvedMeetings = $this->db->table('meeting')
            ->where('ruangan_id', $ruanganId)
            ->where('status', 'approved')
            ->countAllResults();
        
        return $approvedMeetings === 0;
    }

    // Get all meetings for a specific room
    public function getMeetings($ruanganId)
    {
        return $this->db->table('meeting')
            ->select('meeting.*, pegawai.nama as nama_pegawai')
            ->join('pegawai', 'pegawai.id = meeting.pegawai_id')
            ->where('ruangan_id', $ruanganId)
            ->orderBy('waktu_mulai', 'ASC')
            ->get()
            ->getResultArray();
    }

    // Override insert to handle timestamps
    public function insert($data = null, bool $returnID = true)
    {
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');
        return parent::insert($data, $returnID);
    }

    // Override update to handle timestamps
    public function update($id = null, $data = null): bool
    {
        $data['updated_at'] = date('Y-m-d H:i:s');
        return parent::update($id, $data);
    }
}
